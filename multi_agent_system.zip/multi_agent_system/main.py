import os
from typing import Dict, TypedDict, List
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END

# 1. 定义中央状态（State）
class PipelineState(TypedDict):
    idea: str                
    world_and_characters: str 
    outline: str             
    scenes: str              
    audit_passed: bool       
    feedback: str            
    review_count: int        

# 初始化大模型（可替换为 Gemini, OpenAI 等 API）
llm = ChatOpenAI(
    model="gpt-4o-mini", 
    temperature=0.7,
    openai_api_key=os.environ.get("OPENAI_API_KEY", "your-api-key-here")
)

# 2. 定义各个独立的 Agent 节点
def world_building_agent(state: PipelineState) -> Dict:
    print("\n[Agent 1] 正在构建世界观与核心人设冲突矩阵...")
    prompt = ChatPromptTemplate.from_messages([
        ("system", "你是一个资深的网文/短剧架构师。负责根据初始创意，构建逻辑严密、充满张力的世界观和核心人设。核心人物之间必须有强烈的利益或情感冲突。"),
        ("user", "初始创意：{idea}\n\n请输出：\n1. 核心世界观设定\n2. 核心人物矩阵（包含主角、反派的性格与互相冲突）")
    ])
    chain = prompt | llm
    response = chain.invoke({"idea": state["idea"]})
    return {"world_and_characters": response.content, "review_count": state.get("review_count", 0) + 1}

def outline_generator_agent(state: PipelineState) -> Dict:
    print("\n[Agent 2] 正在运用长链推理，生成黄金节奏大纲...")
    prompt = ChatPromptTemplate.from_messages([
        ("system", "你是一个爆款短剧编剧。负责结合世界观，将故事拆解为具备强“爽点”和“悬念钩子”的大纲。运用长链推理，确保前因后果逻辑闭环。"),
        ("user", "世界观与人设：\n{world_and_characters}\n\n请基于此生成一份核心剧情节点的黄金大纲。要求：明确标出每一处的'压迫点'、'反转点'和'留给下一集的悬念钩子'。")
    ])
    chain = prompt | llm
    response = chain.invoke({"world_and_characters": state["world_and_characters"]})
    return {"outline": response.content}

def scene_splitter_agent(state: PipelineState) -> Dict:
    print("\n[Agent 3] 正在对大纲进行十倍扩写，拆解像素级场次细纲...")
    prompt = ChatPromptTemplate.from_messages([
        ("system", "你是一个精细化剧本拆解专家。负责将宏观大纲，拆解为具体的场次（Scene）细纲。"),
        ("user", "大纲内容：\n{outline}\n\n请将该大纲内容扩写拆解为详细的细纲。每场必须包含场景人物、核心冲突和读者情绪期望值。")
    ])
    chain = prompt | llm
    response = chain.invoke({"outline": state["outline"]})
    return {"scenes": response.content}

def compliance_audit_agent(state: PipelineState) -> Dict:
    print("\n[Agent 4] 正在对生成的场次细纲进行逻辑一致性与合规性审计...")
    if state.get("review_count", 0) >= 3:
         return {"audit_passed": True, "feedback": "已达最大迭代次数，强制通过。"}
         
    prompt = ChatPromptTemplate.from_messages([
        ("system", "你是一个严苛的剧本总监。负责审计下属写出的场次细纲。你需要检查是否存在逻辑前后矛盾、人设崩塌。"),
        ("user", "原始世界观：\n{world_and_characters}\n\n生成的场次细纲：\n{scenes}\n\n请进行深度推理审计。如果合格，首行请只输出 'PASS'。如果不合格，首行输出 'FAIL'，并在后续列出具体的修改意见。")
    ])
    chain = prompt | llm
    response = chain.invoke({"world_and_characters": state["world_and_characters"], "scenes": state["scenes"]})
    
    result_text = response.content.strip()
    if result_text.startswith("PASS"):
        return {"audit_passed": True, "feedback": "审计完全通过。"}
    else:
        return {"audit_passed": False, "feedback": result_text}

# 3. 构建 LangGraph 工作流拓扑图
workflow = StateGraph(PipelineState)
workflow.add_node("world_builder", world_building_agent)
workflow.add_node("outline_generator", outline_generator_agent)
workflow.add_node("scene_splitter", scene_splitter_agent)
workflow.add_node("auditor", compliance_audit_agent)

workflow.set_entry_point("world_builder")
workflow.add_edge("world_builder", "outline_generator")
workflow.add_edge("outline_generator", "scene_splitter")
workflow.add_edge("scene_splitter", "auditor")

def determine_next_step(state: PipelineState):
    if state["audit_passed"]:
        return "end"
    else:
        return "rebuild"

workflow.add_conditional_edges("auditor", determine_next_step, {"end": END, "rebuild": "world_builder"})
app = workflow.compile()

if __name__ == "__main__":
    initial_input = {
        "idea": "一个现代外卖员意外获得了一个‘万物皆可好评返现’的系统，只要给雇主解决麻烦并拿到好评，就能暴击获得对方的能力或财富。",
        "review_count": 0, "audit_passed": False, "feedback": ""
    }
    final_output = app.invoke(initial_input)
    print("\n[系统最终交付产物]:\n", final_output["scenes"])