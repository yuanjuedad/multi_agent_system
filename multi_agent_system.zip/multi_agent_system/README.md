# 多Agent协同剧本运营自动化系统 (Multi-Agent Story System)

## 1. 架构设计 (Architecture)
本项目基于工业级 LangGraph 状态机框架构建，完全解耦了传统的单 Prompt 文本生成模式，设计了 4 个具备独立上下文与职能的智能体进行分布式协同：
- **WorldBuilderAgent**：负责底层世界观与人物强冲突矩阵推理。
- **OutlineAgent**：负责黄金节奏点与爽点悬念钩子埋线。
- **SceneSplitterAgent**：负责像素级场次细纲的长文本深度扩写。
- **AuditorAgent**：负责长链反向推理，校验逻辑闭环，并触发自动反思纠偏（Critique Loop）。

## 2. 自动化闭环与 Token 消耗模式
系统维持一个中央状态机（State Machine）在各节点间异步传递结构化数据。由 Auditor 智能体进行逻辑审计，若审计不通过，系统将携带完整的 Feedback 反思意见自动打回重构，形成完全自动化的闭环修正。该机制在实际网文/短剧批量生产运营中会带来高频、高吞吐的 Token 消耗，完美契合大模型厂商对长链推理与企业级自动化应用场景的扶持标准。